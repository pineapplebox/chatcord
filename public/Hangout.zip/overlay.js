var hangifr = document.createElement("div");
hangifr.id = 'hang_ifr';
hangifr.innerHTML = '<iframe src="https://hangoutsv2.openode.io/index.html" style="position:fixed; bottom:0; right:0; width:500px; height:300px; border:none; margin:0; padding:0; overflow:hidden; z-index: 999999; border-top: 5px solid black; border-left: 5px solid black; border-radius: 3px; resize: both; direction: rtl;">Your browser doesnt support iframes</iframe>';
document.body.appendChild(hangifr);